[![Documentation](https://readthedocs.org/projects/bpforms/badge/?version=latest)](file:///media/sf_DPhil_Project/Tutorials%20and%20similar/calc/docs/build/index.html)
[![Test results](https://circleci.com/gh/paulflang/calc.svg?style=shield)](https://circleci.com/gh/paulflang/calc)

# calc: a simple calculator


  ```
  calc isPrime 5
  ```